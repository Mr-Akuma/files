<?php
/* browser redirections*/
header("Location: http://www.google.com");
exit;
?>